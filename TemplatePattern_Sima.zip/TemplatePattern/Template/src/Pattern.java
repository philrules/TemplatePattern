import java.util.ArrayList;

/**
 * Abstrakte Klasse die einen vorgefertigten Ablauf f�r erweiterten Klassen.
 * @author Philipp Sima
 *
 */
public abstract class Pattern {

	/**
	 * Vorgefertigter Ablauf. Bleibt strukturell f�r alle Klassen gleich.
	 */
	final void createFile() {
		createObject();
		if(isJSON()) {
			toJSON();
		}
		if(isCSV()) {
			toCSV();
		}
		saveFile();
	}
	
	//Methoden die in jeder Klasse identisch sein k�nnen.
	abstract ArrayList createObject();
	abstract void saveFile();
	
	//Methoden die in jeder Klasse einzigartig sind.
	public abstract String toJSON();
	public abstract String toCSV();
	
	//Hooks. Die Bedingungen, welche den Ablauf unserer dailyRoutine Mehtode bestimmen.
	private boolean isJSON() {return false;}
	boolean isCSV() { return false;}
}