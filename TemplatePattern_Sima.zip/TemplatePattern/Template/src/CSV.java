import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * Objekte vom Typ User zu einem CSV Format formatieren und in einem TextFile abspeichern.
 * 
 * @author Philipp Sima
 */
public class CSV extends Pattern {
	
	private ArrayList<User> user = new ArrayList<User>();
	private Scanner scan = new Scanner(System.in);
	
	/**
	 * @return boolean der definiert ob die Klasse im vorgefertigtem Ablauf als CSV behandelt wird.
	 */
	boolean isCSV() {return true;}
	
	/**
	 * Formatierung der User Objekten zu einem JSON Format.
	 * @return Formatierter CSV String
	 */
	@Override
    public String toCSV() {
		String data ="";
		
		for(int i = 0; i<user.size(); i++) {
			user.get(i);
	        data = "\n";
	        data += user.get(i).getId();
	        data += ";"+ user.get(i).getName();
	        data += ";"+ user.get(i).getMessage();
		}
        
        return data;
    }

	/**
	 * Objekt vom Typen User erstellen.
	 * @return ArrayListe vom Typ User.
	 */
	@Override
	public ArrayList createObject() {
		System.out.println("Benutzer anlegen:");
		System.out.println("");
		System.out.println("ID: ");
		int id = scan.nextInt();
		System.out.println("Name: ");
		String name = scan.next();
		System.out.println("Nachricht: ");
		String message = scan.next();
		
		User u = new User(id, name, message);
		user.add(u);
		
		return user;
	}
	
	/**
	 * User in ein Textdokument speichern.
	 * Dokument wird als "JSON.txt" gespeichert.
	 */
	@Override
	public void saveFile() {
		String text = toCSV();
		
		try (PrintWriter out = new PrintWriter("CSV.txt")) {
		    out.println(text);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}	
	}

	@Override
	public String toJSON() {
		// TODO Auto-generated method stub
		return null;
	}
    
}