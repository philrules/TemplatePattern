
public class Main {

	public static void main(String[] args) {
		CSV c = new CSV();
		JSON j = new JSON();
		
		j.createFile();
		c.createFile();		
	}
}
