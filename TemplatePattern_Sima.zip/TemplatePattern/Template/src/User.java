/**
 * Klasse dient als Grundlage f�r sp�tere formatierung.
 * 
 * @author Philipp Sima
 */
public class User {

	private String name, message;
	private int id;
	
	public User(int id, String name, String message) {
		setId(id);
		setName(name);
		setMessage(message);
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	

}
