import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * Objekte vom Typ User zu einem JSON Format formatieren und in einem TextFile abspeichern.
 * 
 * @author Philipp Sima
 */
public class JSON extends Pattern {

	private ArrayList<User> user= new ArrayList<User>();
	private Scanner scan = new Scanner(System.in);
	
	/**
	 * @return boolean der definiert ob die Klasse im vorgefertigtem Ablauf als JSON behandelt wird.
	 */
	private boolean isJSON() {return true;}
	
	/**
	 * Formatierung der User Objekten zu einem JSON Format.
	 * @return Formatierter JSON String
	 */
	@Override
	public String toJSON(){
	    
		String data = "";
		for(int i = 0; i<user.size(); i++) {
	    data += "{";
	    data += "\n\"Id\": " + user.get(i).getId() + ",";
	    data += "\n\"Name\": \"" + user.get(i).getName() + "\"" + ",";
	    data += "\n\"Nachricht\": " + user.get(i).getMessage() + ",";
	    data += "\n}";
		}
		
	    return data;
	}
	
	/**
	 * Objekt vom Typen User erstellen.
	 * @return ArrayListe vom Typ User.
	 */
	@Override
	public ArrayList createObject() {
		System.out.println("Benutzer anlegen:");
		System.out.println("");
		System.out.println("ID: ");
		int id = scan.nextInt();
		System.out.println("Name: ");
		String name = scan.next();
		System.out.println("Nachricht: ");
		String message = scan.next();
			
		User u = new User(id, name, message);
		user.add(u);
		
		return user;
	}
		
	/**
	 * User in ein Textdokument speichern.
	 * Dokument wird als "JSON.txt" gespeichert.
	 */
	@Override
	public void saveFile() {
		String text = toJSON();
			
		try (PrintWriter out = new PrintWriter("JSON.txt")) {
		    out.println(text);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}			
	}

	@Override
	public String toCSV() {
		// TODO Auto-generated method stub
		return null;
	}
}
